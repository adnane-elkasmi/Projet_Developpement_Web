<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title> Prospection EISTI </title>
    </head>

    <body style='margin-left:170px'>
        <section>
            <table>
                <tr>
                    <td>Terminales</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Premières</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>MP</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>PC</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>PSI</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>PT</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>ATS</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Sup</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Secondes</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Parents</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Collégiens</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>DUT GEII</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>DUT Informatique</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>DUT STID</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Autre</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>CPE</td>
                    <td>variable</td>
                </tr>
                <tr>
                    <td>Proviseur</td>
                    <td>variable</td>
                </tr>
            </table>
        </section>
    </body>
</html>
